<?php

class BidangNalarTahun extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('wajib_detail_model');
    }

    public function index($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/index',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tindustri($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/tindustri',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tmesin($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/tmesin',$datatahun);
        $this->load->view('templates/footer');

    }

    public function informatika($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/informatika',$datatahun);
        $this->load->view('templates/footer');

    }

    public function telektro($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/telektro',$datatahun);
        $this->load->view('templates/footer');

    }

    public function aero($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartahun/aero',$datatahun);
        $this->load->view('templates/footer');

    }


}