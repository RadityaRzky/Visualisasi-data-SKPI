<?php 

class Giatlain extends CI_Controller{

    public function index()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlain/index');
        $this->load->view('templates/footer');

        
    }


}



?>
