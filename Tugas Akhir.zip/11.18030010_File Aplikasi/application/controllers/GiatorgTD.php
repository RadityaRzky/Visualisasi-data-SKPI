<?php 
Class GiatorgTD extends CI_Controller {

    public function index()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/index');
        $this->load->view('templates/footer');


    }

    public function giatorgti()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/giatorgti');
        $this->load->view('templates/footer');


    }

    public function giatorgif()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/giatorgif');
        $this->load->view('templates/footer');


    }

    public function giatorgtm()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/giatorgtm');
        $this->load->view('templates/footer');


    }

    public function giatorgte()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/giatorgte');
        $this->load->view('templates/footer');


    }

    
    public function giatorgaero()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatorgtd/giatorgaero');
        $this->load->view('templates/footer');


    }









}