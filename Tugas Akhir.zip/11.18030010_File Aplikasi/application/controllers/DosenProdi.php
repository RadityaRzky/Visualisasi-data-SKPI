<?php

class DosenProdi extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('dosen_detail_model');
    }


    public function index($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/index',$datatahun);
        $this->load->view('templates/footer');

    }

    public function telektro($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/telektro',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tindustri($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/tindustri',$datatahun);
        $this->load->view('templates/footer');

    }


    public function tmesin($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/tmesin',$datatahun);
        $this->load->view('templates/footer');

    }

    public function informatika($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/informatika',$datatahun);
        $this->load->view('templates/footer');

    }

    public function aero($jurusan)

    {
        $datatahun['tahun']=$this->dosen_detail_model->detailjurusan($jurusan);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('dosenprodi/aero',$datatahun);
        $this->load->view('templates/footer');

    }
}