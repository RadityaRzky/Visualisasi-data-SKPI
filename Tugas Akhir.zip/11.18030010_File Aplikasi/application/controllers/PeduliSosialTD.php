<?php 

class PeduliSosialTD extends CI_Controller{


    public function index()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/index');
        $this->load->view('templates/footer');


    }

    public function pedulisosialti()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/pedulisosialti');
        $this->load->view('templates/footer');


    }

    public function pedulisosialif()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/pedulisosialif');
        $this->load->view('templates/footer');


    }


    public function pedulisosialtm()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/pedulisosialtm');
        $this->load->view('templates/footer');


    }

    public function pedulisosialte()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/pedulisosialte');
        $this->load->view('templates/footer');


    }

    public function pedulisosialaero()
    {

        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('pedulisosialtd/pedulisosialaero');
        $this->load->view('templates/footer');


    }
}






?>