<?php

class BidangnalarTD extends CI_Controller{


    public function index()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/index');
        $this->load->view('templates/footer');

        
    }

    public function bidangnalarti()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/bidangnalarti');
        $this->load->view('templates/footer');

        
    }

    public function bidangnalarif()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/bidangnalarif');
        $this->load->view('templates/footer');

        
    }

    public function bidangnalartm()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/bidangnalartm');
        $this->load->view('templates/footer');

        
    }
    public function bidangnalarte()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/bidangnalarte');
        $this->load->view('templates/footer');

        
    }

    public function bidangnalaraero()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('bidangnalartd/bidangnalaraero');
        $this->load->view('templates/footer');

        
    }



}