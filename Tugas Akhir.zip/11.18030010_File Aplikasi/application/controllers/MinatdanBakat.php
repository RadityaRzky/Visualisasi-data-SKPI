<?php 

class MinatdanBakat extends CI_Controller{

    public function index()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('minatdanbakat/index');
        $this->load->view('templates/footer');

        
    }


}



?>
