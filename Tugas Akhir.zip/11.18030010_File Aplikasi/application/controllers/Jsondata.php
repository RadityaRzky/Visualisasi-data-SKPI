<?php
class Jsondata extends CI_Controller{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Db_json_model');
    }
    public function index()
    {

        $data['carinama'] = $this->input->get('carinama');
        $data_array['datalist'] = $this->Db_json_model->getAllData($data['carinama'] );
        
        $data['judul']='Data Json';
        $this->load->view('templates/header',$data);
        $this->load->view('jsondata/index',$data_array);
        $this->load->view('templates/footer');


    }



}