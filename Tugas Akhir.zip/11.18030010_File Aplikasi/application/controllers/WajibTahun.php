<?php

class WajibTahun extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('wajib_detail_model');
    }

    public function index($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/index',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tindustri($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/tindustri',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tmesin($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/tmesin',$datatahun);
        $this->load->view('templates/footer');

    }

    public function informatika($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/informatika',$datatahun);
        $this->load->view('templates/footer');

    }

    public function telektro($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/telektro',$datatahun);
        $this->load->view('templates/footer');

    }

    public function aero($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtahun/aero',$datatahun);
        $this->load->view('templates/footer');

    }


}