<?php
class WajibTD extends CI_Controller{