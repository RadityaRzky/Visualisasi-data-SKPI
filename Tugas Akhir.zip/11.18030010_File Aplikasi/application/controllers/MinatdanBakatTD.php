<?php

class MinatdanBakatTD extends CI_Controller{

    public function index()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/index');
            $this->load->view('templates/footer');
    

    }

    public function minatbakatti()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/minatbakatti');
            $this->load->view('templates/footer');
    

    }

    public function minatbakatif()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/minatbakatif');
            $this->load->view('templates/footer');
    

    }

    public function minatbakattm()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/minatbakattm');
            $this->load->view('templates/footer');
    

    }

    public function minatbakatte()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/minatbakatte');
            $this->load->view('templates/footer');
    

    }

    public function minatbakataero()
    {

        
            $data['judul']='Kegiatan Mahasiswa';
            $this->load->view('templates/header',$data);
            $this->load->view('minatdanbakattd/minatbakataero');
            $this->load->view('templates/footer');
    

    }






}