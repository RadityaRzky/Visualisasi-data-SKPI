<?php

class GiatlainTD extends CI_Controller{


    public function index()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/index');
        $this->load->view('templates/footer');

        
    }

    public function giatlainti()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/giatlainti');
        $this->load->view('templates/footer');

        
    }

    public function giatlainif()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/giatlainif');
        $this->load->view('templates/footer');

        
    }

    public function giatlaintm()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/giatlaintm');
        $this->load->view('templates/footer');

        
    }
    public function giatlainte()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/giatlainte');
        $this->load->view('templates/footer');

        
    }

    public function giatlainaero()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintd/giatlainaero');
        $this->load->view('templates/footer');

        
    }


}