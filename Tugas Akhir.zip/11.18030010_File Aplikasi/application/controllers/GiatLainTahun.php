<?php

class GiatLainTahun extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('wajib_detail_model');
    }

    public function index($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/index',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tindustri($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/tindustri',$datatahun);
        $this->load->view('templates/footer');

    }

    public function tmesin($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/tmesin',$datatahun);
        $this->load->view('templates/footer');

    }

    public function informatika($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/informatika',$datatahun);
        $this->load->view('templates/footer');

    }

    public function telektro($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/telektro',$datatahun);
        $this->load->view('templates/footer');

    }

    public function aero($id)

    {
        $datatahun['tahun']=$this->wajib_detail_model->detailtahun($id);
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('giatlaintahun/aero',$datatahun);
        $this->load->view('templates/footer');

    }


}