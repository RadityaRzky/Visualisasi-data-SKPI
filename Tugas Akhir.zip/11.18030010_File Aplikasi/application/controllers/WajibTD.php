<?php 

class WajibTD extends CI_Controller{

    public function index()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/index');
        $this->load->view('templates/footer');

        
    }


    public function wajibti()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/wajibti');
        $this->load->view('templates/footer');

        
    }

    public function wajibif()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/wajibif');
        $this->load->view('templates/footer');

        
    }

    public function wajibtm()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/wajibtm');
        $this->load->view('templates/footer');

        
    }

    public function wajibte()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/wajibte');
        $this->load->view('templates/footer');

        
    }

    public function wajibaero()
    {
        $data['judul']='Kegiatan Mahasiswa';
        $this->load->view('templates/header',$data);
        $this->load->view('wajibtd/wajibaero');
        $this->load->view('templates/footer');

        
    }










}



?>
