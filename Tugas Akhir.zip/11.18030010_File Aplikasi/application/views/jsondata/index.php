
<div class="container mt-3">
<h5 class="card-title text-center" style="height: 0.1px;"><a href="#" class="list-group-item list-group-item-action"  style="font-size:meidum; font-weight:bold; background-color: #243763 !important;color:white;">Data Kegiatan Mahasiswa</a></h5>
    
</div>

<div class="container-md mt-3" style="padding-top: 33px;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-3"></div>
        <div class="col-sm-3"></div>
        <div class="col-sm-3">
            <br>
            <form class="d-flex" role="search" action="" method="GET">
                <input class="form-control me-2" type="text" placeholder="Search" aria-label="Search" name="carinama" >
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
    

</div>
<div class="container mt-3">

<div class="row">
        <div class="col-sm-2">
                <div class="card-group">
                    <div class="card" style="width: 5rem;">
                        <div class="list-group">
                            <a href="<?= base_url(); ?>" class="list-group-item list-group-item-action" aria-current="true" style="font-size:small; background-color: #243763 !important;color:white;">
                                Kegiatan Wajib
                            </a>
                            <a href="<?= base_url(); ?>giatorganisasi" class="list-group-item list-group-item-action" style="font-size:small; background-color: #243763 !important;color:white;">Kegiatan Organisasi dan Kepemimpinan</a>
                            <a href="<?= base_url(); ?>bidangnalar" class="list-group-item list-group-item-action" style="font-size:small; background-color: #243763 !important;color:white;">Kegiatan Bidang Penalaran dan Keilmuan</a>
                            <a href="<?= base_url(); ?>minatdanbakat" class="list-group-item list-group-item-action " style="font-size:small; background-color: #243763 !important;color:white;">Kegiatan Minat dan Bakat</a>
                            <a href="<?= base_url(); ?>pedulisosial" class="list-group-item list-group-item-action" style="font-size:small; background-color: #243763 !important;color:white;">Kegiatan Kepedulian Sosial</a>
                            <a href="<?= base_url(); ?>giatlain" class="list-group-item list-group-item-action " style="font-size:small; background-color: #243763 !important;color:white;">Kegiatan Lainnya</a>
                            <a href="<?= base_url(); ?>dosenajar" class="list-group-item list-group-item-action"style="font-size:small; background-color: #243763 !important;color:white;">Keaktifan dosen verifikasi data SKPI</a>
                            <a href="<?= base_url();?>jsondata" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;color:white;">Database</a>
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                            <a href="#" class="list-group-item list-group-item-action "  style="font-size:small; background-color: #243763 !important;"></a>     
                                   
                        </div>
                    </div>
                </div>
        </div>
        <div class="col-sm-5">
        <div class="container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">NIM</th>
                        <th scope="col">Nama Mahasiswa</th>
                        <th scope="col">Nama Prodi</th>
                        <th scope="col">Nama Kegiatan</th>
                        <th scope="col">Detail Kegiatan</th>
                        <th scope="col">Skor</th>
                        <th scope="col">Dosen Verifikator</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
        $start = 0;
        foreach ($datalist as $value)
        {
            ?>
        <tr>
            <th scope="row"><?php echo ++$start ?></th>
            <td><?php echo $value["nim"];?></td>
            <td><?php echo $value["nama"];?></td>
            <td><?php echo $value["nama_prodi"];?></td>
            <td><?php echo $value["nm_kegiatan"];?></td>
            <td><?php echo $value["detail_tipe_kegiatan"];?></td>
            <td><?php echo $value["skor"];?></td>
            <td><?php echo $value["verifikator"];?></td>
        </tr>
        <?php
        }
        ?>
    </tbody>
</table>
</div>
</div>
</div>

<script>
    $("input").on("keyup",function(){
        $("tbody tr").filter(function(){
            $(this).toggle($(this).text().toLocaleLowerCase().indexOf($("input").val().toLocaleLowerCase()) > -1);

        });

    });
</script>
