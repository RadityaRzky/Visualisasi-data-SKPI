<?php
# Teknik Dirgantara Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Teknik Dirgantara');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

#$query =json_encode($this->db->get()->result_array(),true);
#$data_array = array('datalist'=>$query);
#$data_array1 = $data_array['datalist'];
#var_dump ($query);
foreach ($query as $value)
{
$nm_giat[]=$value["detail_tipe_kegiatan"];
$jml_giat[]=$value["nm"];

}
#echo json_encode($nm_giat);
#echo json_encode($jml_giat);

# Teknik Teknik Industri Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Teknik Industri');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

foreach ($query as $value)
{
$nm_giat1[]=$value["detail_tipe_kegiatan"];
$jml_giat1[]=$value["nm"];

}


# Infromatika Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Informatika');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

foreach ($query as $value)
{
$nm_giat2[]=$value["detail_tipe_kegiatan"];
$jml_giat2[]=$value["nm"];

}

# Teknik Mesin Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Teknik Mesin');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

foreach ($query as $value)
{
$nm_giat3[]=$value["detail_tipe_kegiatan"];
$jml_giat3[]=$value["nm"];

}


# Teknik Elektro Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Teknik Elektro');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

foreach ($query as $value)
{
$nm_giat4[]=$value["detail_tipe_kegiatan"];
$jml_giat4[]=$value["nm"];

}


# Teknik Aeronautika Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Aeronautika');
$this->db->where('nm_kegiatan','Kegiatan Bidang Kepedulian Sosial');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();


foreach ($query as $value)
{
$nm_giat5[]=$value["detail_tipe_kegiatan"];
$jml_giat5[]=$value["nm"];

}

?>

<div class="container mt-3">
<h5 class="card-title text-center" style="height: 0.1px;"><a href="#" class="list-group-item list-group-item-action"  style="font-size:meidum; font-weight:bold;background-color: #243763 !important;color:white;">Kegiatan Kepedulian Sosial</a></h5>
   
</div>

<div class="container mt-3" style="padding-top: 35px;">
    <div class="row">
        <div class="col-sm-2">
            <div class="card-group">
                <div class="card" style="width: 5rem;">
                    <div class="list-group">
                        <a href="<?= base_url(); ?>" class="list-group-item list-group-item-action" aria-current="true" style="font-size:small;background-color: #243763 !important;color:white;">
                            Kegiatan Wajib
                        </a>
                        <a href="<?= base_url(); ?>giatorganisasi" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Organisasi dan Kepemimpinan</a>
                        <a href="<?= base_url(); ?>bidangnalar" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Bidang Penalaran dan Keilmuan</a>
                        <a href="<?= base_url(); ?>minatdanbakat" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Minat dan Bakat</a>
                        <a href="<?= base_url(); ?>pedulisosial" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Kepeduian Sosial</a>
                        <a href="<?= base_url(); ?>giatlain" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Lainnya</a>
                        <a href="<?= base_url(); ?>dosenajar" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Keaktifan dosen verifikasi data SKPI</a>
                        <a href="<?= base_url();?>jsondata" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;">Database</a>
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        
                    </div>
                </div>
                    
            </div>
        </div>
        <div class="col-sm-10">
                            
            <div class="card-group">
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues = <?= json_encode($nm_giat)?>;
                                var yValues = <?= json_encode($jml_giat)?>;
                                var barColors = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart", {
                                type: "pie",
                                data: {
                                    labels:xValues  ,
                                    datasets: [{
                                    backgroundColor: barColors,
                                    data: yValues
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Teknik Dirgantara"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>
                                
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart1" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues1 = <?= json_encode($nm_giat1)?>;
                                var yValues1 = <?= json_encode($jml_giat1)?>;
                                var barColors1 = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart1", {
                                type: "pie",
                                data: {
                                    labels:xValues1  ,
                                    datasets: [{
                                    backgroundColor: barColors1,
                                    data: yValues1
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Teknik Industri"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd/pedulisosialti" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>

            </div>

            <div class="card-group">
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart2" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues2 = <?= json_encode($nm_giat2)?>;
                                var yValues2 = <?= json_encode($jml_giat2)?>;
                                var barColors2 = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart2", {
                                type: "pie",
                                data: {
                                    labels:xValues2  ,
                                    datasets: [{
                                    backgroundColor: barColors2,
                                    data: yValues2
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Informatika"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd/pedulisosialif" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>
                                
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart3" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues3 = <?= json_encode($nm_giat3)?>;
                                var yValues3 = <?= json_encode($jml_giat3)?>;
                                var barColors3 = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart3", {
                                type: "pie",
                                data: {
                                    labels:xValues3  ,
                                    datasets: [{
                                    backgroundColor: barColors3,
                                    data: yValues3
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Teknik Mesin"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd/pedulisosialtm" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>

            </div>

            <div class="card-group">
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart4" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues4 = <?= json_encode($nm_giat4)?>;
                                var yValues4 = <?= json_encode($jml_giat4)?>;
                                var barColors4 = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart4", {
                                type: "pie",
                                data: {
                                    labels:xValues4  ,
                                    datasets: [{
                                    backgroundColor: barColors4,
                                    data: yValues4
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Teknik Elektro"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd/pedulisosialte" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>
                                
                <div class="card" style="width: 10rem;">
                        <canvas id="myChart5" style="width:100%;max-width:600px"></canvas>
                        <script>
                                var xValues5 = <?= json_encode($nm_giat5)?>;
                                var yValues5 = <?= json_encode($jml_giat5)?>;
                                var barColors5 = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7145",
                                "#1e7145"
                                ];

                                new Chart("myChart5", {
                                type: "pie",
                                data: {
                                    labels:xValues5  ,
                                    datasets: [{
                                    backgroundColor: barColors5,
                                    data: yValues5
                                    }]
                                },
                                options: {
                                    title: {
                                    display: true,
                                    text: "Aeronautika"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>pedulisosialtd/pedulisosialaero" class="btn btn-primary btn-sm" style="font-size:small;">Lihat Detail</a>
                            </div>  
                </div>

            </div>
        </div>
       
    </div>
</div>