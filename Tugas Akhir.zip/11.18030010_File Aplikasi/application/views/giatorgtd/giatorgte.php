<?php
# Teknik Dirgantara Kegiatan Wajib
$this->db->select('detail_tipe_kegiatan,COUNT(detail_tipe_kegiatan) AS nm');
$this->db->from('datakegiatan');
$this->db->where('nama_prodi','Teknik Elektro');
$this->db->where('nm_kegiatan','Kegiatan Bidang Organisasi dan Kepemimpinan');
$this->db->group_by('detail_tipe_kegiatan');

$query=$this->db->get()->result_array();

#$query =json_encode($this->db->get()->result_array(),true);
#$data_array = array('datalist'=>$query);
#$data_array1 = $data_array['datalist'];
#var_dump ($query);
foreach ($query as $value)
{
$nm_giat[]=$value["detail_tipe_kegiatan"];
$jml_giat[]=$value["nm"];

}
#echo json_encode($nm_giat);
#echo json_encode($jml_giat);



?>

<div class="container mt-3">
<h5 class="card-title text-center" style="height: 0.1px;"><a href="#" class="list-group-item list-group-item-action"  style="font-size:meidum; font-weight:bold;background-color: #243763 !important;color:white;">Kegiatan Organisasi dan Kepemimpinan</a></h5>
</div>

<div class="container mt-3" style="padding-top: 35px;">
    <div class="row">
        <div class="col-sm-2">
            <div class="card-group">
                <div class="card" style="width: 5rem;">
                    <div class="list-group">
                        <a href="<?= base_url(); ?>" class="list-group-item list-group-item-action" aria-current="true" style="font-size:small;background-color: #243763 !important;color:white;">
                            Kegiatan Wajib
                        </a>
                        <a href="<?= base_url(); ?>giatorganisasi" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Organisasi dan Kepemimpinan</a>
                        <a href="<?= base_url(); ?>bidangnalar" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Bidang Penalaran dan Keilmuan</a>
                        <a href="<?= base_url(); ?>minatdanbakat" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Minat dan Bakat</a>
                        <a href="<?= base_url(); ?>pedulisosial" class="list-group-item list-group-item-action" style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Kepedulian Sosial</a>
                        <a href="<?= base_url(); ?>giatlain" class="list-group-item list-group-item-action " style="font-size:small;background-color: #243763 !important;color:white;">Kegiatan Lainnya</a>
                        <a href="<?= base_url(); ?>dosenajar" class="list-group-item list-group-item-action " style="font-size:small;background-color: #243763 !important;color:white;">Keaktifan dosen verifikasi data SKPI</a>
                        <a href="<?= base_url();?>jsondata" class="list-group-item list-group-item-action "  style="font-size:small;background-color: #243763 !important;color:white;">Database</a>
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                        <a href="#" class="list-group-item list-group-item-action"  style="font-size:small;background-color: #243763 !important;color:white;"></a>     
                           
                    </div>
                </div>
                    
            </div>
                            
        </div>
        <div class="col-sm-10">
            <div class="card-group">
                <div class="card" style="width: 30rem;">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false" style="font-size:small;">
                    Tahun
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/15" style="font-size:small;">2015</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/16" style="font-size:small;">2016</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/17" style="font-size:small;">2017</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/18" style="font-size:small;">2018</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/19" style="font-size:small;">2019</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/20" style="font-size:small;">2020</a>
                        <a class="dropdown-item" href="<?= base_url(); ?>giatorgtahun/telektro/21" style="font-size:small;">2021</a>
                    </div>
                </div>
                        <canvas id="myChart" style="width:100%;max-width:900px"></canvas>
                        <script>
                                var xValues = <?= json_encode($nm_giat)?>;
                                var yValues = <?= json_encode($jml_giat)?>;
                                var barColors = [
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149",
                                "#b91d47",
                                "#00aba9",
                                "#2b5797",
                                "#e8c3b9",
                                "#1e7145",
                                "#1e7148",
                                "#1e7149"
                                ];

                                new Chart("myChart", {
                                type: "bar",
                                data: {
                                    labels: xValues,
                                    datasets: [{
                                    backgroundColor: barColors,
                                    data: yValues
                                    }]
                                },
                                options: {
                                    legend: {display: false},
                                    title: {
                                    display: true,
                                    text: "Teknik Elektro"
                                    }
                                }
                                });
                        </script>
                            <div class="card-body">
                    
                                <a href="<?= base_url(); ?>giatorganisasi" class="btn btn-primary btn-sm" style="font-size:small;">Kembali</a>
                            </div>  
                </div>
                                
                

            </div>
        </div>
       
    </div>
</div>


