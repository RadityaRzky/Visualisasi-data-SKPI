<?php

class dosen_detail_model extends CI_model{

public function detailjurusan($jurusan)
{
    return $jurusan;
    
} 


}