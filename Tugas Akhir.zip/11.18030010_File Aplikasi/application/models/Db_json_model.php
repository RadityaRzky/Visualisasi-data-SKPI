<?php

class Db_json_model extends CI_model{

    public function getAllData($carinama)

    {
        
        if (!$carinama){
            $url="https://perpustakaan.itda.ac.id/api/pengesahan_skpi.php";
            $get_url = file_get_contents($url);
            $data_json = json_decode($get_url,true);
            
            $data_array = array(
                'datalist' => $data_json["data"]
                );
            //var_dump($data_array["datalist"]);
                $xx = count($data_array["datalist"])-1;
                $this->db->empty_table('datakegiatan');

            //$this->db->insert('detailkegiatan', $data_array["datalist"][0]);
            
            for($x = 0; $x <= $xx; $x++)
            {
               $this->db->insert('datakegiatan', $data_array["datalist"][$x]);
            }
            //return $data_array;
            $query_prodi = "Update datakegiatan SET nama_prodi ='Teknik Elektro' where nama_prodi ='TE'";
            $this->db->query($query_prodi);
            $query_prodi = "Update datakegiatan SET nama_prodi ='Informatika' where nama_prodi ='IF'";
            $this->db->query($query_prodi);
            $query_prodi = "Update datakegiatan SET nama_prodi ='Teknik Dirgantara' where nama_prodi ='TD'";
            $this->db->query($query_prodi);
            $query_prodi = "Update datakegiatan SET nama_prodi ='Teknik Industri' where nama_prodi ='TI'";
            $this->db->query($query_prodi);
            $query_prodi = "Update datakegiatan SET nama_prodi ='Teknik Mesin' where nama_prodi ='TM'";
            $this->db->query($query_prodi);
            $query_prodi = "Update datakegiatan SET nama_prodi ='Aeronautika' where nama_prodi ='D3 AERO'";
            $this->db->query($query_prodi);
           
                
            return $this->db->get('datakegiatan')->result_array();
        }
        else{
            $this->db->like('nama', $carinama);
            return $this->db->get('datakegiatan')->result_array();

        }
    }



}