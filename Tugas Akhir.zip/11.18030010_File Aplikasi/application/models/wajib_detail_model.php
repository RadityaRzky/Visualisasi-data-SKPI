<?php

class wajib_detail_model extends CI_model{

    public function detailtahun($id)
    
    {
       $tahun = $id;
       return $tahun;

    }

}